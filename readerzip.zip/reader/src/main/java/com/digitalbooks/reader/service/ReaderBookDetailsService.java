package com.digitalbooks.reader.service;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.digitalbooks.reader.readerDb.entity.SubscribeBook;
import com.digitalbooks.reader.readerDb.repository.SubscribeBookRepository;

@Service
public class ReaderBookDetailsService {
	@Autowired
	private SubscribeBookRepository subscribeRepo;
	
	@Autowired
	private JavaMailSender javaMailSender;
	
	public SubscribeBook readerSubscribeBook(SubscribeBook subscribeBook) {
		subscribeRepo.save(subscribeBook);
		return subscribeBook;
	}
	
	public String readerUnsubscribeBook(int transactionId) {
		String res = "";
		//SubscribeBook subBook = subscribeRepo.findByTransactionId(transactionId);
			res = "unsubscribes successfully";		
		
		return res;
	}
	
	public List<SubscribeBook> subscribedBooks(int readerId){
		List<SubscribeBook> listBooks = subscribeRepo.findByReaderId(readerId);
		
		return listBooks;
	}
	@KafkaListener(
			topics = "blocked-book", 
			groupId="group_id", 
			containerFactory = "userKafkaListenerFactory"
		)
	public void blockedMailMessage(int bookId) {
		System.out.println(" kafka book id "+bookId);
		List<SubscribeBook> list = subscribeRepo.findByBookId(bookId);
		if(list.isEmpty()) {
			
			//throw new MovieNotFoundException("Movie with id ("+id+") not found in db");
		} else {
			for(SubscribeBook book: list) {
				String toMail = book.getEmailId();
				sendMail(toMail);
			}
		}
	}
	private void sendMail(String receiverMail) {
		MimeMessage mimeMessage = javaMailSender.createMimeMessage();
		try {
		String str = "Dear reader, \n      Your subscribed book was blocked by author";
		
		MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage, true);
		mimeMessageHelper.setSubject("Blocked book details");
		mimeMessageHelper.setFrom("");
		mimeMessageHelper.setTo(receiverMail);
		// mimeMessageHelper.setCc(null);
		mimeMessageHelper.setText(str, true);

		javaMailSender.send(mimeMessageHelper.getMimeMessage());
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
}
