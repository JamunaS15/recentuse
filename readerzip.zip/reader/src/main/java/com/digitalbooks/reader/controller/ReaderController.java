package com.digitalbooks.reader.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.digitalbooks.reader.readerDb.entity.SubscribeBook;
import com.digitalbooks.reader.service.ReaderBookDetailsService;

@RestController
@RequestMapping("/api/v1/digitalbooks/reader")
public class ReaderController {
	@Autowired
	private ReaderBookDetailsService readerBookService;
	
	@PostMapping("/subscribe")
	public ResponseEntity<?> subscribeBook(@RequestBody SubscribeBook subscribeBook){
		SubscribeBook subscribe = readerBookService.readerSubscribeBook(subscribeBook);
		return ResponseEntity.ok(subscribe);
	}
	
	@GetMapping("/unsubscribe/{transactionId}")
	public ResponseEntity<String> unsubscribeBook(@PathVariable int transactionId){
		String res = readerBookService.readerUnsubscribeBook(transactionId);
		return ResponseEntity.ok(res);
	}
	
	@GetMapping("/subscribeList/{readerId}")
	public ResponseEntity<?> subscribeList(@PathVariable int readerId){
		List<SubscribeBook> listBooks = readerBookService.subscribedBooks(readerId);
		return ResponseEntity.ok(listBooks);
	}
	
	@GetMapping("/blockedMail/{bookId}")
	public ResponseEntity<?> blockedMailSend(@PathVariable int bookId){
		readerBookService.blockedMailMessage(bookId);
		return ResponseEntity.ok("mail send successfully");
	}
}
