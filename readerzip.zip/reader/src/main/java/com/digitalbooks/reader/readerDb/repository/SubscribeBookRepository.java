package com.digitalbooks.reader.readerDb.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.digitalbooks.reader.readerDb.entity.SubscribeBook;

@Repository
public interface SubscribeBookRepository extends JpaRepository<SubscribeBook, Integer>{
	@Transactional
    @Modifying
	@Query(nativeQuery = true, value = "update subscribe_book s set s.unsubscribe = true where s.transaction_id = :transactionId")
	void updateUnsubscribeBook(int transactionId);

	
	@Query(nativeQuery = true, value = "select * from subscribe_book s where s.reader_id = :readerId")
	List<SubscribeBook> findByReaderId(int readerId);
}
